package xiangshan.backend.fu.mu  
  
import chisel3._  
import chisel3.util._  
import xiangshan._  
import xiangshan.backend.fu._  
  
class madd_i16_mm_Module(implicit p: Parameters) extends XSModule {  
  val io = IO(new Bundle() {  
    val ms2_data = Input(UInt(XLEN.W))  
    val ms1_data = Input(UInt(XLEN.W))  
    val md_data   = Output(UInt(XLEN.W))  
  })  
  
  val num_elem = XLEN / 16  
  val ms2_vec = Wire(Vec(num_elem, SInt(16.W)))  
  val ms1_vec = Wire(Vec(num_elem, SInt(16.W)))  
  val md_vec = Wire(Vec(num_elem, UInt(16.W)))  
  
  for(i <- 0 until num_elem) {  
    ms2_vec(i) := io.ms2_data(16*(i+1)-1, 16*i).asSInt  
    ms1_vec(i) := io.ms1_data(16*(i+1)-1, 16*i).asSInt  
    md_vec(i) := ms2_vec(i) + ms1_vec(i) // Matrix addition  
  }  
  
  io.md_data := md_vec.reduce{ (a, b) => Cat(b, a) }  
}  
  
class MuDataModule(implicit p: Parameters) extends XSModule {  
  val io = IO(new Bundle() {  
    val src = Vec(2, Input(UInt(XLEN.W)))  
    val OpType = Input(FuOpType())  
    val result = Output(UInt(XLEN.W))  
  })  
  val (src1, src2) = (io.src(0), io.src(1))  
  
  val madd_i16_mm_module = Module(new madd_i16_mm_Module)  
  
  madd_i16_mm_module.io.ms2_data := src2  
  madd_i16_mm_module.io.ms1_data := src1  
  
  io.result := Mux(io.OpType === MuOpType.madd_i16_mm, madd_i16_mm_module.io.md_data, 0.U(XLEN.W))  
}  
  
class MU(implicit p: Parameters) extends FunctionUnit {  
  val dataModule = Module(new MuDataModule)  
  dataModule.io.src := io.in.bits.src.take(2)  
  dataModule.io.OpType := io.in.bits.uop.ctrl.fuOpType  
  io.in.ready := io.out.ready  
  io.out.valid := io.in.valid  
  io.out.bits.uop <> io.in.bits.uop  
  io.out.bits.data := dataModule.io.result  
}